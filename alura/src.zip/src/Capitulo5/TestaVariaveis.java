package Capitulo5;

public class TestaVariaveis {

    public static void main(String[] args){

        System.out.println("Ola novo teste");

        int idade = 37/2*2+1;

        System.out.println("A idade é " + idade  + " , parabéns ");
    }
}
