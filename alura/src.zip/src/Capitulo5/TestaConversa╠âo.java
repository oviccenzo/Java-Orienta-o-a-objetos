package Capitulo5;

public class TestaConversão {
    public static void main(String[] args){

        float PontoFlutuante = 3.14F;
        double Salario = 1270.50/2;
        int Valor = (int) Salario;
        System.out.println(STR."O valor é: \{Valor}");

        double Valor1 = 0.2;
        double Valor2 = 0.1;
        double Valor3 = 0.3;
        double Valor4 = 0.4;
        double Valor5 = 1;
        double ValorTotal = Valor1 + Valor2 + Valor3 + Valor4 + Valor5;

        System.out.println(STR."O valor total é: \{ValorTotal}");
    }
}
