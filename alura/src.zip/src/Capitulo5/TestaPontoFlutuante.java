package Capitulo5;

public class TestaPontoFlutuante {
    public static void main(String[] args){

        double Salario = 1350.70;

        System.out.println(STR."Meu salario é: \{Salario}");

        double Divisão = 7.0/ 2;

        System.out.println(STR."A divisão é: \{Divisão}");
    }
}
