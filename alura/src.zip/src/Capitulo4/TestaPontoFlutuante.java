package Capitulo4;

public class TestaPontoFlutuante {
    public static void main(String[] args){

        double Salario = 1250.70;

        System.out.println("Meu salario é: " + Salario);

        double Divisão = 5.0 / 2 ;
        System.out.println("A divisão: " + Divisão);
    }
}
