package Capitulo4;

public class TestaVariaveis {
    public static void main(String[] args){

        System.out.println("Olá novo teste");

        int idade = 37;

        System.out.println("A idade é " + idade + ", parabéns");
    }
}
