package Capitulo6;

public class TestaCaractere {
    public static void main(String[] args){

        char Letra = 'a';
        System.out.println(Letra);

         char Valor = 65;
         System.out.println(Valor);

        //Valor = (char) (Valor + 1);
        //System.out.println(Valor);

        String Palavra = " Alura cursos online de tecnologia  ";
        System.out.println(Palavra);

        Palavra = Palavra + 2020;
        System.out.println(Palavra);
    }
}
