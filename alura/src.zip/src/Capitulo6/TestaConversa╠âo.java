package Capitulo6;

public class TestaConversão {
    public static void main(String[] args){

        float PontoFlutuante = 3.14F;

        double Salario = 1470.50/2*2;
        int Valor = (int) Salario;
        System.out.println(Valor);

        double Valor1 = 0.9;
        double Valor2 = 0.1;
        double ValorTotal = Valor1 + Valor2;

        System.out.println(STR."O valor total é: \{ValorTotal}");
    }
}
