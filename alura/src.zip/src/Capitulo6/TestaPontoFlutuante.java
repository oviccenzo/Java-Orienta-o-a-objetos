package Capitulo6;

public class TestaPontoFlutuante {
    public static void main(String[] args){

        double Salario = 1750.60;
        System.out.println(STR."O meu salario é: \{Salario}");

        double Divisão = 9.0/2;
        System.out.println(STR."A divisão é: \{Divisão}");

    }
}
