package Teste;

public class Conta {
    double saldo;
}
