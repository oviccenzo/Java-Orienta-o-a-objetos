package Pessoa;

public class Pessoa {
    String nome;
    int idade ;
    int peso;
}
