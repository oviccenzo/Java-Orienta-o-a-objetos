package Pessoa;

public class Main {
    public static void main(String[] args){

        Pessoa heroi = new Pessoa();
        heroi.nome = "johny";

    }
}
