package Capitulo2;

public class AjudaAnaComSeuCodigo {
    public static void main(String[] args){
        System.out.println("Voce pode ajudar a ana?");

        String parcela1 = "20";
        String parcela2 = "10";

        System.out.println(parcela1 + parcela2);
    }

}

