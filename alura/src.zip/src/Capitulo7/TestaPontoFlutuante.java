package Capitulo7;

public class TestaPontoFlutuante {

    public static void main(String[] args){

        double salario = 1550.70;

        System.out.println("O meu salario é: " + salario);

        double divisão = 7.0/2;
        System.out.println("A divisão é: "+divisão);
    }
}
