package Capitulo7;

public class TestaFor {

    public static void main(String[] args){

        for (int contar = 10; contar <= 110; contar++){
            System.out.println( contar );
        }
    }
}
