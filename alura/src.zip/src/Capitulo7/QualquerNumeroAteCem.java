package Capitulo7;

public class QualquerNumeroAteCem {

    public static void main(String[] args){

        for(int i = 2; i < 100; i+= 2){
            System.out.println("O numero é: " + i);
        }
    }
}
